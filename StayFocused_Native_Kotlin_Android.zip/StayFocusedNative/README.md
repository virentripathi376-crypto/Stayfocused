# Stay Focused (Simple Native Kotlin Android App)

A lightweight, native Kotlin Android app modeled after **Stay Focused 11.0.0**, featuring real system-level app & website blocking, screen time tracking, Instagram Reels & YouTube Shorts blocking, Strict Mode, Take a Break, and a Pomodoro timer.

## Core Native Features
1. **Real Screen Time & Launch Tracking (`UsageStatsHelper.kt`)**:
   - Uses Android's `UsageStatsManager` (`android.permission.PACKAGE_USAGE_STATS`) to calculate exact daily screen time and launch counts for every installed app.
2. **Real-Time App, Website & Reels/Shorts Blocker (`FocusAccessibilityService.kt`)**:
   - Uses `AccessibilityService` to detect foreground app launches and compare them against your configured rules:
     - **Daily Time Limit** (mins/day)
     - **Max Launch Count Limit** (opens/day)
     - **Scheduled Block Window** (e.g., 09:00–17:00)
     - **Wait Timer / Mindfulness Cooldown** (seconds before opening)
     - **Always Blocked / Take a Break Mode**
   - **In-App Reels & Shorts Shield**: Detects Instagram Reels (`com.instagram.android`) and YouTube Shorts (`com.google.android.youtube`) view nodes and blocks short-video feeds while keeping messaging/search usable.
   - **Browser Keyword Blocker**: Reads browser URL bars (`com.android.chrome`) and blocks URLs/queries matching your keyword blocklist.
3. **Strict Mode & Anti-Uninstall (`FocusDeviceAdminReceiver.kt`)**:
   - Locks your rules behind a **Random Text Challenge** or **4-digit PIN** and optionally uses `DeviceAdminReceiver` to prevent impulsive uninstallation.
4. **Native Block Screen (`BlockedOverlayActivity.kt`)**:
   - Intercepts blocked apps with a motivational quote, block reason, optional Wait Timer countdown, and a button to return to the Android Home Screen.

---

## How to Build the `.apk`

### Method A: In Android Studio (Local PC/Mac)
1. Extract `StayFocused_Native_Kotlin_Android.zip`.
2. Open **Android Studio** -> **Open** -> select the extracted folder.
3. Wait for Gradle Sync to finish, then click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your installable APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

### Method B: Without Installing Android Studio (Free Cloud Build via GitHub Actions)
1. Create a new repository on GitHub and upload these project files.
2. Open the **Actions** tab in your GitHub repository and run the **Build Stay Focused Android APK** workflow.
3. Download `StayFocused-Simple-debug-apk` directly to your phone and install it.
