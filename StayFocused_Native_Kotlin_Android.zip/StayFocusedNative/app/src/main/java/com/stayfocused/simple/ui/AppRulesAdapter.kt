package com.stayfocused.simple.ui

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.stayfocused.simple.databinding.ItemAppRuleBinding
import com.stayfocused.simple.model.LimitType
import com.stayfocused.simple.model.InstalledAppInfo

class AppRulesAdapter(
    private val packageManager: PackageManager,
    private val onConfigureClick: (InstalledAppInfo) -> Unit
) : RecyclerView.Adapter<AppRulesAdapter.ViewHolder>() {

    private val items = mutableListOf<InstalledAppInfo>()

    fun submitList(newItems: List<InstalledAppInfo>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: ItemAppRuleBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAppRuleBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        with(holder.binding) {
            tvAppName.text = item.appName
            tvUsageStats.text = "${item.usedMinutesToday}m today • ${item.launchesToday} opens"

            val ruleDesc = when (item.rule.limitType) {
                LimitType.NONE -> "No limit set"
                LimitType.DAILY_TIME -> "Daily Limit: ${item.rule.limitValue}m/day"
                LimitType.LAUNCH_COUNT -> "Launch Cap: ${item.rule.limitValue}/day"
                LimitType.SCHEDULE -> "Blocked ${item.rule.scheduleStartHour}:00–${item.rule.scheduleEndHour}:00"
                LimitType.WAIT_TIMER -> "Wait Timer: ${item.rule.limitValue}s"
                LimitType.ALWAYS_BLOCKED -> "🔒 Always Blocked"
            }
            tvRuleBadge.text = ruleDesc

            val progress = if (item.rule.limitType == LimitType.DAILY_TIME && item.rule.limitValue > 0) {
                ((item.usedMinutesToday * 100) / item.rule.limitValue).coerceIn(0, 100)
            } else {
                (item.usedMinutesToday * 2).coerceIn(0, 100)
            }
            progressUsage.progress = progress

            try {
                ivAppIcon.setImageDrawable(packageManager.getApplicationIcon(item.packageName))
            } catch (e: Exception) {
                ivAppIcon.setImageResource(android.R.drawable.sym_def_app_icon)
            }

            btnConfigureRule.setOnClickListener {
                onConfigureClick(item)
            }
        }
    }
}
