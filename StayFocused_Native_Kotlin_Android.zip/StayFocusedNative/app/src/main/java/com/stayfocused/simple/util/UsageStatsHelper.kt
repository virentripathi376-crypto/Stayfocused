package com.stayfocused.simple.util

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.util.Calendar

object UsageStatsHelper {

    data class DailyUsageSummary(
        val totalScreenTimeMinutes: Int,
        val totalLaunches: Int,
        val perPackageMinutes: Map<String, Int>,
        val perPackageLaunches: Map<String, Int>
    )

    fun hasUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun getTodayUsageSummary(context: Context): DailyUsageSummary {
        if (!hasUsageStatsPermission(context)) {
            return DailyUsageSummary(0, 0, emptyMap(), emptyMap())
        }

        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfDay = cal.timeInMillis
        val now = System.currentTimeMillis()

        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, startOfDay, now)
        val minutesMap = mutableMapOf<String, Int>()
        var totalMillis = 0L

        for (stat in stats) {
            if (stat.totalTimeInForeground > 0) {
                val mins = (stat.totalTimeInForeground / 60_000L).toInt()
                if (mins > 0) {
                    minutesMap[stat.packageName] = (minutesMap[stat.packageName] ?: 0) + mins
                    totalMillis += stat.totalTimeInForeground
                }
            }
        }

        // Count activity foreground launches via UsageEvents
        val events = usm.queryEvents(startOfDay, now)
        val launchesMap = mutableMapOf<String, Int>()
        var totalLaunches = 0
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                val pkg = event.packageName ?: continue
                launchesMap[pkg] = (launchesMap[pkg] ?: 0) + 1
                totalLaunches++
            }
        }

        return DailyUsageSummary(
            totalScreenTimeMinutes = (totalMillis / 60_000L).toInt(),
            totalLaunches = totalLaunches,
            perPackageMinutes = minutesMap,
            perPackageLaunches = launchesMap
        )
    }
}
