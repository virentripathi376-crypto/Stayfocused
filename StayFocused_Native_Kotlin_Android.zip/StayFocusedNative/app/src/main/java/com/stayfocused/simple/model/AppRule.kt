package com.stayfocused.simple.model

enum class LimitType(val displayName: String) {
    NONE("No Limit"),
    DAILY_TIME("Daily Usage Limit (mins/day)"),
    LAUNCH_COUNT("Max Launches per Day"),
    SCHEDULE("Scheduled Block Window"),
    WAIT_TIMER("Mindfulness Wait Timer (sec)"),
    ALWAYS_BLOCKED("Always Blocked (Quick Lock)")
}

data class AppRule(
    val packageName: String,
    val appName: String,
    var limitType: LimitType = LimitType.NONE,
    var limitValue: Int = 30,
    var scheduleStartHour: Int = 9,
    var scheduleEndHour: Int = 17,
    var motivationalQuote: String = "Stay focused on your goals! Your future self will thank you."
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val usedMinutesToday: Int,
    val launchesToday: Int,
    val rule: AppRule
)
