package com.stayfocused.simple.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.stayfocused.simple.data.FocusRepository
import com.stayfocused.simple.databinding.ActivityMainBinding
import com.stayfocused.simple.databinding.DialogConfigureLimitBinding
import com.stayfocused.simple.model.LimitType
import com.stayfocused.simple.model.InstalledAppInfo
import com.stayfocused.simple.util.UsageStatsHelper
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: FocusRepository
    private lateinit var adapter: AppRulesAdapter

    private var pomodoroTimer: CountDownTimer? = null
    private var pomodoroRunning = false
    private var pomodoroSecondsRemaining = 25 * 60

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = FocusRepository(this)
        adapter = AppRulesAdapter(packageManager) { appInfo ->
            showConfigureLimitDialog(appInfo)
        }

        binding.rvApps.layoutManager = LinearLayoutManager(this)
        binding.rvApps.adapter = adapter

        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        refreshDashboardAndApps()
    }

    private fun setupListeners() {
        // Permission Setup Buttons
        binding.btnGrantUsage.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        binding.btnGrantAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Quick Take a Break Button
        binding.btnTakeABreak.setOnClickListener {
            showTakeABreakDialog()
        }

        // Reels & Shorts Toggles
        binding.switchIgReels.isChecked = repository.blockInstagramReels
        binding.switchYtShorts.isChecked = repository.blockYoutubeShorts

        binding.switchIgReels.setOnCheckedChangeListener { buttonView, isChecked ->
            if (repository.isStrictModeEnabled && !isChecked) {
                buttonView.isChecked = true
                Toast.makeText(this, "🔒 Strict Mode is ON! Cannot unblock Reels.", Toast.LENGTH_SHORT).show()
                return@setOnCheckedChangeListener
            }
            repository.blockInstagramReels = isChecked
        }

        binding.switchYtShorts.setOnCheckedChangeListener { buttonView, isChecked ->
            if (repository.isStrictModeEnabled && !isChecked) {
                buttonView.isChecked = true
                Toast.makeText(this, "🔒 Strict Mode is ON! Cannot unblock Shorts.", Toast.LENGTH_SHORT).show()
                return@setOnCheckedChangeListener
            }
            repository.blockYoutubeShorts = isChecked
        }

        // Strict Mode Button
        binding.btnToggleStrictMode.setOnClickListener {
            if (!repository.isStrictModeEnabled) {
                repository.isStrictModeEnabled = true
                refreshDashboardAndApps()
                Toast.makeText(this, "🔒 Strict Mode Activated!", Toast.LENGTH_SHORT).show()
            } else {
                showStrictModeChallengeDialog()
            }
        }

        // Pomodoro Controls
        binding.btnPomodoroToggle.setOnClickListener {
            if (pomodoroRunning) {
                pomodoroTimer?.cancel()
                pomodoroRunning = false
                binding.btnPomodoroToggle.text = "▶ Start 25m Focus"
            } else {
                startPomodoro()
            }
        }
    }

    private fun refreshDashboardAndApps() {
        val hasUsage = UsageStatsHelper.hasUsageStatsPermission(this)
        val hasAcc = isAccessibilityServiceEnabled()

        binding.cardPermissions.visibility = if (hasUsage && hasAcc) View.GONE else View.VISIBLE
        binding.btnGrantUsage.visibility = if (hasUsage) View.GONE else View.VISIBLE
        binding.btnGrantAccessibility.visibility = if (hasAcc) View.GONE else View.VISIBLE

        val summary = UsageStatsHelper.getTodayUsageSummary(this)
        val hours = summary.totalScreenTimeMinutes / 60
        val mins = summary.totalScreenTimeMinutes % 60
        binding.tvTotalScreenTime.text = "${hours}h ${mins}m"
        binding.tvTotalLaunches.text = "${summary.totalLaunches}"
        binding.tvBlockedCount.text = "${repository.getBlockedAttemptsToday()}"

        // Strict Mode UI
        if (repository.isStrictModeEnabled) {
            binding.btnToggleStrictMode.text = "🔓 Unlock Strict Mode (Challenge)"
            binding.tvStrictBadge.text = "🔒 STRICT ON"
        } else {
            binding.btnToggleStrictMode.text = "🔒 Activate Strict Mode"
            binding.tvStrictBadge.text = "● Active"
        }

        // Load user-installed launchable apps
        val pm = packageManager
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { app ->
                pm.getLaunchIntentForPackage(app.packageName) != null &&
                    app.packageName != packageName &&
                    (app.flags and ApplicationInfo.FLAG_SYSTEM == 0 ||
                        app.packageName.contains("youtube") ||
                        app.packageName.contains("chrome"))
            }
            .map { app ->
                val label = pm.getApplicationLabel(app).toString()
                val used = summary.perPackageMinutes[app.packageName] ?: 0
                val opens = summary.perPackageLaunches[app.packageName] ?: 0
                val rule = repository.getRuleForPackage(app.packageName, label)
                InstalledAppInfo(app.packageName, label, used, opens, rule)
            }
            .sortedWith(compareByDescending<InstalledAppInfo> { it.usedMinutesToday }.thenBy { it.appName })

        adapter.submitList(installed)
    }

    private fun showConfigureLimitDialog(appInfo: InstalledAppInfo) {
        if (repository.isStrictModeEnabled) {
            Toast.makeText(
                this,
                "🔒 Strict Mode is ON! Unlock Strict Mode first to modify limits.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val dialogBinding = DialogConfigureLimitBinding.inflate(LayoutInflater.from(this))
        val types = LimitType.values()
        dialogBinding.spinnerLimitType.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            types.map { it.displayName }
        )
        dialogBinding.spinnerLimitType.setSelection(types.indexOf(appInfo.rule.limitType))
        dialogBinding.etLimitValue.setText(appInfo.rule.limitValue.toString())
        dialogBinding.etQuote.setText(appInfo.rule.motivationalQuote)

        AlertDialog.Builder(this)
            .setTitle("Limit for ${appInfo.appName}")
            .setView(dialogBinding.root)
            .setPositiveButton("Save Rule") { _, _ ->
                val selectedType = types[dialogBinding.spinnerLimitType.selectedItemPosition]
                val value = dialogBinding.etLimitValue.text.toString().toIntOrNull() ?: 30
                val quote = dialogBinding.etQuote.text.toString().ifBlank {
                    "Stay focused on your goals!"
                }
                val updated = appInfo.rule.copy(
                    limitType = selectedType,
                    limitValue = value.coerceAtLeast(1),
                    motivationalQuote = quote
                )
                repository.saveRule(updated)
                refreshDashboardAndApps()
                Toast.makeText(this, "Saved rule for ${appInfo.appName}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showTakeABreakDialog() {
        val options = arrayOf("10 minutes", "15 minutes", "30 minutes", "60 minutes")
        val minsValues = intArrayOf(10, 15, 30, 60)
        AlertDialog.Builder(this)
            .setTitle("☕ Take a Break from Your Phone")
            .setItems(options) { _, which ->
                val mins = minsValues[which]
                repository.takeBreakUntilMillis = System.currentTimeMillis() + mins * 60_000L
                Toast.makeText(
                    this,
                    "☕ Take a Break started for $mins minutes!",
                    Toast.LENGTH_LONG
                ).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showStrictModeChallengeDialog() {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
        val challenge = "SF-" + (1..12).map { chars[Random.nextInt(chars.length)] }.joinToString("")
        val input = EditText(this).apply {
            hint = "Type exact string above"
        }

        AlertDialog.Builder(this)
            .setTitle("🔒 Strict Mode Challenge")
            .setMessage("Type this exact random sequence to unlock Strict Mode:\n\n$challenge")
            .setView(input)
            .setPositiveButton("Verify") { _, _ ->
                if (input.text.toString().trim() == challenge) {
                    repository.isStrictModeEnabled = false
                    refreshDashboardAndApps()
                    Toast.makeText(this, "🔓 Strict Mode unlocked", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Incorrect sequence! Strict Mode stays ON.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Keep Locked", null)
            .show()
    }

    private fun startPomodoro() {
        pomodoroRunning = true
        binding.btnPomodoroToggle.text = "⏸ Pause Focus"
        pomodoroTimer?.cancel()
        pomodoroTimer = object : CountDownTimer(pomodoroSecondsRemaining * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                pomodoroSecondsRemaining = (millisUntilFinished / 1000L).toInt()
                val m = pomodoroSecondsRemaining / 60
                val s = pomodoroSecondsRemaining % 60
                binding.tvPomodoroTimer.text = String.format("%02d:%02d", m, s)
            }

            override fun onFinish() {
                pomodoroRunning = false
                pomodoroSecondsRemaining = 25 * 60
                binding.tvPomodoroTimer.text = "25:00"
                binding.btnPomodoroToggle.text = "▶ Start 25m Focus"
                Toast.makeText(this@MainActivity, "🍅 Pomodoro Session Complete!", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }
}
