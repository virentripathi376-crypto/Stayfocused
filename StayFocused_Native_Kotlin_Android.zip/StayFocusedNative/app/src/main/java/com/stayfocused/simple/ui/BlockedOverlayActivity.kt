package com.stayfocused.simple.ui

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.stayfocused.simple.data.FocusRepository
import com.stayfocused.simple.databinding.ActivityBlockedOverlayBinding

class BlockedOverlayActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBlockedOverlayBinding
    private lateinit var repository: FocusRepository
    private var waitTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlockedOverlayBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = FocusRepository(this)

        val pkg = intent.getStringExtra("EXTRA_PKG") ?: ""
        val appName = intent.getStringExtra("EXTRA_APP_NAME") ?: "App"
        val badge = intent.getStringExtra("EXTRA_BADGE") ?: "Access Blocked"
        val reason = intent.getStringExtra("EXTRA_REASON") ?: "You crossed your configured usage limit."
        val quote = intent.getStringExtra("EXTRA_QUOTE") ?: "Stay focused on your goals!"
        val isWait = intent.getBooleanExtra("EXTRA_IS_WAIT", false)
        val waitSec = intent.getIntExtra("EXTRA_WAIT_SEC", 5)

        binding.tvBadge.text = badge
        binding.tvBlockedTitle.text = "$appName is Blocked"
        binding.tvBlockedReason.text = reason
        binding.tvMotivationalQuote.text = "\"$quote\""

        if (isWait && waitSec > 0) {
            binding.tvWaitCountdown.visibility = View.VISIBLE
            binding.btnProceedAfterWait.visibility = View.GONE
            waitTimer = object : CountDownTimer(waitSec * 1000L, 1000L) {
                override fun onTick(millisUntilFinished: Long) {
                    val sec = (millisUntilFinished / 1000L) + 1
                    binding.tvWaitCountdown.text = "Mindfulness Wait: ${sec}s"
                }

                override fun onFinish() {
                    binding.tvWaitCountdown.text = "Mindfulness Pause Complete"
                    binding.btnProceedAfterWait.visibility = View.VISIBLE
                }
            }.start()
        } else {
            binding.tvWaitCountdown.visibility = View.GONE
            binding.btnProceedAfterWait.visibility = View.GONE
        }

        binding.btnProceedAfterWait.setOnClickListener {
            if (pkg.isNotEmpty()) {
                repository.grantTemporaryPass(pkg, durationMinutes = 5)
            }
            finish()
        }

        binding.btnGoHome.setOnClickListener {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
            finish()
        }
    }

    override fun onDestroy() {
        waitTimer?.cancel()
        super.onDestroy()
    }
}
