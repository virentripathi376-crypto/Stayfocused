package com.stayfocused.simple.data

import android.content.Context
import android.content.SharedPreferences
import com.stayfocused.simple.model.AppRule
import com.stayfocused.simple.model.LimitType
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class FocusRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("stay_focused_prefs", Context.MODE_PRIVATE)

    // --- App Limit Rules ---
    fun getRuleForPackage(packageName: String, defaultAppName: String = packageName): AppRule {
        val raw = prefs.getString("rule_$packageName", null) ?: return AppRule(packageName, defaultAppName)
        return try {
            val obj = JSONObject(raw)
            AppRule(
                packageName = packageName,
                appName = obj.optString("appName", defaultAppName),
                limitType = LimitType.valueOf(obj.optString("limitType", LimitType.NONE.name)),
                limitValue = obj.optInt("limitValue", 30),
                scheduleStartHour = obj.optInt("scheduleStartHour", 9),
                scheduleEndHour = obj.optInt("scheduleEndHour", 17),
                motivationalQuote = obj.optString(
                    "motivationalQuote",
                    "Stay focused on your goals! Your future self will thank you."
                )
            )
        } catch (e: Exception) {
            AppRule(packageName, defaultAppName)
        }
    }

    fun saveRule(rule: AppRule) {
        val obj = JSONObject().apply {
            put("packageName", rule.packageName)
            put("appName", rule.appName)
            put("limitType", rule.limitType.name)
            put("limitValue", rule.limitValue)
            put("scheduleStartHour", rule.scheduleStartHour)
            put("scheduleEndHour", rule.scheduleEndHour)
            put("motivationalQuote", rule.motivationalQuote)
        }
        prefs.edit().putString("rule_${rule.packageName}", obj.toString()).apply()
    }

    // --- Wait Timer Grace Window (allows 5 mins of usage after completing Wait Timer) ---
    fun grantTemporaryPass(packageName: String, durationMinutes: Int = 5) {
        val expiry = System.currentTimeMillis() + durationMinutes * 60_000L
        prefs.edit().putLong("temp_pass_$packageName", expiry).apply()
    }

    fun hasValidTemporaryPass(packageName: String): Boolean {
        val expiry = prefs.getLong("temp_pass_$packageName", 0L)
        return System.currentTimeMillis() < expiry
    }

    // --- Reels & Shorts Shield ---
    var blockInstagramReels: Boolean
        get() = prefs.getBoolean("block_ig_reels", true)
        set(value) = prefs.edit().putBoolean("block_ig_reels", value).apply()

    var blockYoutubeShorts: Boolean
        get() = prefs.getBoolean("block_yt_shorts", true)
        set(value) = prefs.edit().putBoolean("block_yt_shorts", value).apply()

    // --- Keyword Blocklist ---
    fun getBlockedKeywords(): List<String> {
        val raw = prefs.getString("blocked_keywords", "casino,gossip,doomscroll") ?: ""
        return raw.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
    }

    fun setBlockedKeywords(keywords: List<String>) {
        prefs.edit().putString("blocked_keywords", keywords.joinToString(",")).apply()
    }

    // --- Strict Mode & PIN Lock ---
    var isStrictModeEnabled: Boolean
        get() = prefs.getBoolean("strict_mode_enabled", false)
        set(value) = prefs.edit().putBoolean("strict_mode_enabled", value).apply()

    var lockPin: String
        get() = prefs.getString("lock_pin", "2580") ?: "2580"
        set(value) = prefs.edit().putString("lock_pin", value).apply()

    // --- Take a Break Global Pause ---
    var takeBreakUntilMillis: Long
        get() = prefs.getLong("take_break_until", 0L)
        set(value) = prefs.edit().putLong("take_break_until", value).apply()

    fun isTakeABreakActive(): Boolean {
        return System.currentTimeMillis() < takeBreakUntilMillis
    }

    fun getTakeBreakRemainingSeconds(): Long {
        val rem = (takeBreakUntilMillis - System.currentTimeMillis()) / 1000L
        return if (rem > 0) rem else 0L
    }

    // --- Distractions Blocked Counter ---
    fun incrementBlockedCount() {
        val count = getBlockedAttemptsToday() + 1
        prefs.edit().putInt("blocked_attempts_today", count).apply()
    }

    fun getBlockedAttemptsToday(): Int {
        return prefs.getInt("blocked_attempts_today", 7)
    }

    // --- Check if a rule currently blocks an app ---
    fun evaluateBlockReason(
        packageName: String,
        usedMinutesToday: Int,
        launchesToday: Int
    ): BlockDecision {
        if (hasValidTemporaryPass(packageName)) {
            return BlockDecision(isBlocked = false)
        }

        if (isTakeABreakActive()) {
            val minsLeft = (getTakeBreakRemainingSeconds() / 60) + 1
            return BlockDecision(
                isBlocked = true,
                badge = "Take a Break Mode",
                reason = "All distracting apps are paused for $minsLeft more minute(s) while you take a break.",
                quote = "Step away from the screen and recharge."
            )
        }

        val rule = getRuleForPackage(packageName)
        return when (rule.limitType) {
            LimitType.NONE -> BlockDecision(isBlocked = false)

            LimitType.ALWAYS_BLOCKED -> BlockDecision(
                isBlocked = true,
                badge = "Quick Block Active",
                reason = "${rule.appName} is locked by your Always Blocked rule.",
                quote = rule.motivationalQuote
            )

            LimitType.DAILY_TIME -> {
                if (usedMinutesToday >= rule.limitValue) {
                    BlockDecision(
                        isBlocked = true,
                        badge = "Daily Limit Reached",
                        reason = "You used ${usedMinutesToday}m today, crossing your ${rule.limitValue}m daily limit.",
                        quote = rule.motivationalQuote
                    )
                } else {
                    BlockDecision(isBlocked = false)
                }
            }

            LimitType.LAUNCH_COUNT -> {
                if (launchesToday >= rule.limitValue) {
                    BlockDecision(
                        isBlocked = true,
                        badge = "Launch Limit Reached",
                        reason = "You opened ${rule.appName} $launchesToday/${rule.limitValue} times today.",
                        quote = rule.motivationalQuote
                    )
                } else {
                    BlockDecision(isBlocked = false)
                }
            }

            LimitType.SCHEDULE -> {
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val inWindow = if (rule.scheduleStartHour <= rule.scheduleEndHour) {
                    hour in rule.scheduleStartHour until rule.scheduleEndHour
                } else {
                    hour >= rule.scheduleStartHour || hour < rule.scheduleEndHour
                }
                if (inWindow) {
                    BlockDecision(
                        isBlocked = true,
                        badge = "Scheduled Focus Window",
                        reason = "${rule.appName} is blocked between ${rule.scheduleStartHour}:00 and ${rule.scheduleEndHour}:00.",
                        quote = rule.motivationalQuote
                    )
                } else {
                    BlockDecision(isBlocked = false)
                }
            }

            LimitType.WAIT_TIMER -> BlockDecision(
                isBlocked = true,
                isWaitTimer = true,
                waitSeconds = rule.limitValue.coerceIn(3, 120),
                badge = "Mindfulness Wait Timer",
                reason = "Take a deep breath and wait ${rule.limitValue} seconds before opening ${rule.appName}.",
                quote = rule.motivationalQuote
            )
        }
    }
}

data class BlockDecision(
    val isBlocked: Boolean,
    val isWaitTimer: Boolean = false,
    val waitSeconds: Int = 0,
    val badge: String = "",
    val reason: String = "",
    val quote: String = ""
)
