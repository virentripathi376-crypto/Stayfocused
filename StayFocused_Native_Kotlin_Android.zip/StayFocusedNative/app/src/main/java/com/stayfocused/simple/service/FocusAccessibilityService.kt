package com.stayfocused.simple.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.stayfocused.simple.data.FocusRepository
import com.stayfocused.simple.ui.BlockedOverlayActivity
import com.stayfocused.simple.util.UsageStatsHelper

class FocusAccessibilityService : AccessibilityService() {

    private lateinit var repository: FocusRepository
    private var lastBlockedTimestamp = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        repository = FocusRepository(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        // Never block our own app, System UI, or default launcher
        if (pkg == applicationContext.packageName ||
            pkg == "com.android.systemui" ||
            pkg.contains("launcher")
        ) {
            return
        }

        // 1. Check In-App Reels & Shorts Shield
        if (pkg == "com.instagram.android" && repository.blockInstagramReels) {
            if (containsViewIdOrText(rootInActiveWindow, "clips_viewer", "reel")) {
                triggerBlockOverlay(
                    packageName = pkg,
                    appName = "Instagram Reels",
                    badge = "Reels Shield Active",
                    reason = "Stay Focused blocked the Instagram Reels infinite feed while keeping DMs & Stories accessible.",
                    quote = "Stop infinite scrolling before it steals your hour."
                )
                return
            }
        }

        if (pkg == "com.google.android.youtube" && repository.blockYoutubeShorts) {
            if (containsViewIdOrText(rootInActiveWindow, "reel_recycler", "reel_player")) {
                triggerBlockOverlay(
                    packageName = pkg,
                    appName = "YouTube Shorts",
                    badge = "Shorts Shield Active",
                    reason = "Stay Focused intercepted the YouTube Shorts player while keeping regular videos accessible.",
                    quote = "Watch long-form educational content with intention."
                )
                return
            }
        }

        // 2. Check Browser Keyword Blocker
        if (pkg == "com.android.chrome" || pkg == "org.mozilla.firefox") {
            val matchedKw = findBlockedKeywordInNode(rootInActiveWindow, repository.getBlockedKeywords())
            if (matchedKw != null) {
                triggerBlockOverlay(
                    packageName = pkg,
                    appName = "Keyword #$matchedKw",
                    badge = "Keyword Filter",
                    reason = "Stay Focused blocked this page because it contains your restricted keyword \"$matchedKw\".",
                    quote = "Protect your focus from clickbait and distractions."
                )
                return
            }
        }

        // 3. Check App-Level Daily Limits, Launch Caps, Schedules & Wait Timers
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val summary = UsageStatsHelper.getTodayUsageSummary(applicationContext)
            val usedMins = summary.perPackageMinutes[pkg] ?: 0
            val launches = summary.perPackageLaunches[pkg] ?: 0
            val decision = repository.evaluateBlockReason(pkg, usedMins, launches)

            if (decision.isBlocked) {
                val rule = repository.getRuleForPackage(pkg, pkg)
                triggerBlockOverlay(
                    packageName = pkg,
                    appName = rule.appName,
                    badge = decision.badge,
                    reason = decision.reason,
                    quote = decision.quote,
                    isWaitTimer = decision.isWaitTimer,
                    waitSeconds = decision.waitSeconds
                )
            }
        }
    }

    private fun containsViewIdOrText(root: AccessibilityNodeInfo?, vararg needles: String): Boolean {
        if (root == null) return false
        val idName = root.viewIdResourceName?.lowercase() ?: ""
        for (needle in needles) {
            if (idName.contains(needle.lowercase())) return true
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            if (containsViewIdOrText(child, *needles)) return true
        }
        return false
    }

    private fun findBlockedKeywordInNode(
        root: AccessibilityNodeInfo?,
        keywords: List<String>
    ): String? {
        if (root == null || keywords.isEmpty()) return null
        val text = root.text?.toString()?.lowercase() ?: ""
        if (text.isNotEmpty()) {
            for (kw in keywords) {
                if (text.contains(kw)) return kw
            }
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val hit = findBlockedKeywordInNode(child, keywords)
            if (hit != null) return hit
        }
        return null
    }

    private fun triggerBlockOverlay(
        packageName: String,
        appName: String,
        badge: String,
        reason: String,
        quote: String,
        isWaitTimer: Boolean = false,
        waitSeconds: Int = 0
    ) {
        val now = System.currentTimeMillis()
        if (now - lastBlockedTimestamp < 1200L) return
        lastBlockedTimestamp = now

        repository.incrementBlockedCount()

        val intent = Intent(this, BlockedOverlayActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("EXTRA_PKG", packageName)
            putExtra("EXTRA_APP_NAME", appName)
            putExtra("EXTRA_BADGE", badge)
            putExtra("EXTRA_REASON", reason)
            putExtra("EXTRA_QUOTE", quote)
            putExtra("EXTRA_IS_WAIT", isWaitTimer)
            putExtra("EXTRA_WAIT_SEC", waitSeconds)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {
        // Required override
    }
}
