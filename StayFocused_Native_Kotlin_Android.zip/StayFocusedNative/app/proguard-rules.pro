# Keep data models
-keep class com.stayfocused.simple.model.** { *; }
